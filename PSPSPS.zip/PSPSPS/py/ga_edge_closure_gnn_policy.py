﻿# ga_edge_closure_gnn_policy.py
# -*- coding: utf-8 -*-

from __future__ import annotations
import argparse
import csv
import gzip
import os
import random
import re
import shutil
import sys
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence, List, Tuple, Dict, Optional, Set

import numpy as np

import time

def _as_file_uri_if_windows(path_str: str) -> str:
    return path_str
    if isinstance(path_str, str):
        if path_str.startswith("file:") or "://" in path_str:
            return path_str
        if re.match(r"^[A-Za-z]:[\\/]", path_str):
            return Path(path_str).resolve().as_uri()
    return path_str


def ensure_sumo_tools_on_path():
    sh = os.environ.get("SUMO_HOME")
    if sh:
        tools = str(Path(sh) / "tools")
        if tools not in sys.path:
            sys.path.append(tools)


def resolve_sumo_bin(explicit: Optional[str]) -> str:
    if explicit:
        return explicit
    cand = shutil.which("sumo")
    if cand:
        return cand
    sh = os.environ.get("SUMO_HOME")
    if sh:
        exe = Path(sh) / "bin" / ("sumo.exe" if os.name == "nt" else "sumo")
        if exe.exists():
            return str(exe)
    raise RuntimeError("sumo 실행파일을 찾지 못했습니다. --sumo-bin 또는 SUMO_HOME을 설정하세요.")


def import_traci_sumolib():
    ensure_sumo_tools_on_path()
    try:
        import traci  # type: ignore
        from sumolib.net import readNet  # type: ignore
        return traci, readNet
    except Exception as e:
        raise RuntimeError("traci/sumolib 임포트 실패. SUMO_HOME/tools 경로 또는 'pip install eclipse-sumo' 확인.") from e


def load_candidates(net_path: str, protect: Set[str], limit: Optional[int]=None) -> Tuple[List[str], Dict[str, List[str]], "sumolib.net.Net"]:
    _, readNet = import_traci_sumolib()
    net = readNet(_as_file_uri_if_windows(net_path))

    def is_drivable_edge(e) -> bool:
        eid = e.getID()
        if eid.startswith(":"): return False
        fn = e.getFunction()
        if fn and fn.lower() == "internal": return False
        if len(e.getLanes()) == 0: return False
        return True

    edges = [e for e in net.getEdges() if is_drivable_edge(e) and e.getID() not in protect]
    cand_ids = [e.getID() for e in edges]
    if limit and len(cand_ids) > limit:
        random.shuffle(cand_ids)
        cand_ids = cand_ids[:limit]

    upstream_map: Dict[str, List[str]] = {}
    for e in edges:
        up: List[str] = []
        for ine in e.getFromNode().getIncoming():
            if ine.getID().startswith(":"): continue
            up.append(ine.getID())
        upstream_map[e.getID()] = up if up else [e.getID()]

    return cand_ids, upstream_map, net


def write_closures_additional(path: Path, closed: Sequence[str], upstream_map: Dict[str, List[str]], begin: int = 0, end: int = 86400) -> None:
    add = ET.Element("additional")
    if closed:
        notify_edges: set[str] = set()
        for e in closed:
            notify_edges.update(upstream_map.get(e, [e]))
        if notify_edges:
            rr = ET.SubElement(add, "rerouter", attrib={
                "id": "rr_close",
                "edges": " ".join(sorted(notify_edges)),
                "probability": "1.0",
            })
            iv = ET.SubElement(rr, "interval", attrib={"begin": str(begin), "end": str(end)})
            for e in closed:
                ET.SubElement(iv, "closingReroute", attrib={"id": e})
    path.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(add).write(path, encoding="UTF-8", xml_declaration=True)


def _extract_route_endpoints(sumocfg_path: str) -> Set[str]:
    endpoints: Set[str] = set()
    try:
        cfg = ET.parse(sumocfg_path).getroot()
        input_node = cfg.find(".//input")
        if input_node is None:
            return endpoints
        route_files_node = input_node.find("route-files")
        if route_files_node is None:
            return endpoints
        value = route_files_node.get("value", "")
        if not value:
            return endpoints
        base = Path(sumocfg_path).parent
        files = [x.strip() for x in value.split(";") if x.strip()]

        def _iter_routes(root: ET.Element):
            for r in root.iter("route"):
                edges = r.get("edges")
                if not edges: 
                    continue
                toks = [t for t in edges.strip().split() if t]
                if toks:
                    endpoints.add(toks[0])
                    endpoints.add(toks[-1])
            for t in root.iter("trip"):
                frm = t.get("from"); to = t.get("to")
                if frm: endpoints.add(frm)
                if to:  endpoints.add(to)

        for f in files:
            rp = base / f
            if not rp.exists():
                rp = Path(f)
                if not rp.exists():
                    continue
            if str(rp).endswith(".gz"):
                with gzip.open(rp, "rb") as g:
                    data = g.read()
                root = ET.fromstring(data)
            else:
                root = ET.parse(rp).getroot()
            _iter_routes(root)
    except Exception:
        pass
    return endpoints


def run_single_sumo_and_score(*,
                       sumo_bin: str,
                       sumocfg: str,
                       additional: Path,
                       outdir: Path,
                       reroute_period: int = 30,
                       step_limit: int = 200000,
                       time_to_teleport: Optional[int] = None,
                       time_to_teleport_highways: Optional[int] = None,
                       emit_tripinfo: bool = True,
                       demand_size: Optional[int] = None) -> float:
    """Run SUMO and return mean trip duration from tripinfo.xml.
       We always write tripinfo to outdir/tripinfo.xml for scoring.
    """
    traci, _ = import_traci_sumolib()
    tripinfo = outdir / "tripinfo.xml"
    sumo_cmd = [
        sumo_bin, "-c", sumocfg, "-a", str(additional),
        "--no-step-log", "true",
        "--tripinfo-output", str(tripinfo),
        "--tripinfo-output.write-unfinished", "true",
        "--device.rerouting.probability", "1.0",
        "--device.rerouting.period", str(reroute_period),
        "--duration-log.disable", "true",
    ]
    if time_to_teleport is not None:
        sumo_cmd += ["--time-to-teleport", str(time_to_teleport)]
    if time_to_teleport_highways is not None:
        sumo_cmd += ["--time-to-teleport.highways", str(time_to_teleport_highways)]

    try:
        traci.start(sumo_cmd, label="ga_run")
        conn = traci.getConnection("ga_run")
        step = 0
        while conn.simulation.getMinExpectedNumber() > 0 and step < step_limit:
            conn.simulationStep(); step += 1
    except Exception:
        try:
            conn.close()
        except Exception:
            pass
        return 1e12

    try:
        conn.close()
    except Exception:
        pass

    if not tripinfo.exists():
        return 1e12

    durations: List[float] = []
    n_vehicles = 0
    try:
        root = ET.parse(tripinfo).getroot()
        for ev in root.iter("tripinfo"):
            n_vehicles += 1

            if ev.attrib.get("vaporized", "false") == "true":
                return 1e12

            ds = ev.attrib.get("duration")
            if ds is None:
                continue
            d = float(ds)
            if d >= 0:
                durations.append(d)
    except Exception:
        return 1e12

    if demand_size is not None and n_vehicles < demand_size:
        return 1e12

    if not durations:
        return 1e12

    return float(np.mean(durations))



def try_load_policy(policy_model_path: Optional[str], net, candidate_ids: List[str]) -> Optional[Dict[str, float]]:
    if not policy_model_path:
        return None
    try:
        import torch
        from policy_gnn_model import PolicyGNN  # requires torch_geometric
        from torch_geometric.nn import GATv2Conv  # noqa: F401
    except Exception as e:
        print("[Policy] torch/torch_geometric/policy_gnn_model 임포트 실패. 무시하고 랜덤으로 진행합니다.", e)
        return None

    # Build simple features compatible with training scripts
    nodes = net.getNodes()
    node_id_map = {n.getID(): i for i, n in enumerate(nodes)}
    N = len(nodes)
    deg_in  = np.zeros((N,1), dtype=np.float32)
    deg_out = np.zeros((N,1), dtype=np.float32)
    is_tls  = np.zeros((N,1), dtype=np.float32)
    for n in nodes:
        i = node_id_map[n.getID()]
        deg_in[i,0]  = len([e for e in n.getIncoming() if not e.getID().startswith(":")])
        deg_out[i,0] = len([e for e in n.getOutgoing() if not e.getID().startswith(":")])
        is_tls[i,0]  = 1.0 if n.getType() == "traffic_light" else 0.0
    x_node = np.concatenate([deg_in, deg_out, is_tls], axis=1)

    edges_all = [e for e in net.getEdges() if not e.getID().startswith(":") and (e.getFunction() or "") != "internal" and len(e.getLanes())>0]
    edge_map = {e.getID(): i for i, e in enumerate(edges_all)}
    E = len(edges_all)
    src = np.array([node_id_map[e.getFromNode().getID()] for e in edges_all], dtype=np.int64)
    dst = np.array([node_id_map[e.getToNode().getID()] for e in edges_all], dtype=np.int64)
    edge_index = np.stack([src, dst], axis=0)

    length   = np.array([e.getLength() for e in edges_all], dtype=np.float32).reshape(E,1)
    lanes    = np.array([len(e.getLanes()) for e in edges_all], dtype=np.float32).reshape(E,1)
    speed    = np.array([e.getSpeed() for e in edges_all], dtype=np.float32).reshape(E,1)
    priority = np.array([(e.getPriority() or 0) for e in edges_all], dtype=np.float32).reshape(E,1)
    from_tls = is_tls[src].astype(np.float32)
    to_tls   = is_tls[dst].astype(np.float32)
    edge_attr = np.concatenate([length, lanes, speed, priority, from_tls, to_tls], axis=1).astype(np.float32)

    import torch
    x_node_t    = torch.tensor(x_node, dtype=torch.float32)
    edge_index_t= torch.tensor(edge_index, dtype=torch.long)
    edge_attr_t = torch.tensor(edge_attr, dtype=torch.float32)

    ck = torch.load(policy_model_path, map_location="cpu")
    sd = ck["state_dict"]
    hid = sd["n_lin.weight"].shape[0]
    heads = sd["gat1.att"].shape[1] if "gat1.att" in sd else 4

    model = PolicyGNN(ck["in_node"], ck["in_edge"], hid=hid, heads=heads)
    model.load_state_dict(sd)
    model.eval()

    with torch.no_grad():
        scores = model(x_node_t, edge_index_t, edge_attr_t).cpu().numpy()  # [E]

    scored: Dict[str, float] = {}
    for eid in candidate_ids:
        idx = edge_map.get(eid, None)
        if idx is not None:
            scored[eid] = float(scores[idx])
    if not scored:
        print("[Policy] 후보 엣지에 대한 스코어가 비었습니다. 랜덤 진행.")
        return None

    # z-score normalize
    arr = np.array(list(scored.values()), dtype=np.float32)
    mu, sdv = float(arr.mean()), float(arr.std() + 1e-6)
    for k in scored:
        scored[k] = (scored[k] - mu) / sdv
    return scored


def _normalize_scores(s):
    s = np.asarray(s, dtype=np.float32)
    m, sd = float(s.mean()), float(s.std())
    return (s - m) / (sd if sd > 1e-12 else 1.0)

def _softmax(x):
    x = x - np.max(x)
    e = np.exp(x)
    return e / (e.sum() + 1e-12)

def _policy_logits(scores, alpha: float):
    return alpha * _normalize_scores(scores)

def _wsample_without_replacement(indexes, probs, k):
    idx = list(indexes)
    p   = [max(1e-12, float(x)) for x in probs]
    out = []
    k = min(k, len(idx))
    for _ in range(k):
        s = sum(p); r = random.random() * s
        acc = 0.0
        j = 0
        for j, w in enumerate(p):
            acc += w
            if acc >= r:
                break
        out.append(idx[j])
        idx.pop(j); p.pop(j)
    return out

def _clamp_bits(bits: List[int], kmin: int, kmax: int):
    ones = [i for i,b in enumerate(bits) if b==1]
    zeros= [i for i,b in enumerate(bits) if b==0]
    k = len(ones)
    if k > kmax:
        random.shuffle(ones)
        for i in ones[:(k-kmax)]: bits[i]=0
    elif k < kmin:
        random.shuffle(zeros)
        for i in zeros[:(kmin-k)]: bits[i]=1
    return bits


@dataclass(frozen=True)
class GAParams:
    mode: str  # "fixed" | "variable"
    k: int
    kmin: int
    kmax: int
    p_init: float
    pc: float
    pm: float
    pop: int
    gen: int
    jobs: int
    begin: int
    end: int
    reroute_period: int
    seed: int
    gnn_usage: str  # none/init/mutation/both
    # policy options
    policy_model: Optional[str]
    seed_ratio: float
    policy_alpha_init: float
    policy_alpha_mut: float
    policy_temp: float
    policy_jitter: int
    # SUMO runtime
    time_to_teleport: Optional[int]
    time_to_teleport_highways: Optional[int]
    emit_tripinfo: bool


def init_population_fixed_guided(cands: List[str], k: int, pop: int,
                                 policy: Optional[Dict[str,float]], seed_ratio: float, jitter: int) -> List[List[str]]:
    m = len(cands)
    popu: List[List[str]] = []
    n_guided = int(pop * max(0.0, min(1.0, seed_ratio)))
    order = list(cands)
    if policy:
        order.sort(key=lambda e: policy.get(e, float('inf')))
    else:
        random.shuffle(order)
    base = order[:max(k,0)]
    for _ in range(n_guided):
        s = set(base[:k])
        for _ in range(max(0, jitter)):
            if not order or len(s)==0: break
            drop = random.choice(tuple(s)); s.remove(drop)
            add_pool = [e for e in order[k:k+20] if e not in s] or [e for e in order if e not in s]
            s.add(random.choice(add_pool))
        popu.append(sorted(s))
    while len(popu) < pop:
        popu.append(sorted(random.sample(cands, k)))
    return popu


def init_population_bits_guided(cands: List[str], p_init: float, pop: int,
                                kmin: int, kmax: int, policy: Optional[Dict[str,float]],
                                alpha_init: float, temp: float) -> List[List[int]]:
    m = len(cands)
    popu: List[List[int]] = []
    if policy:
        scores = np.array([policy.get(e, 0.0) for e in cands], dtype=np.float32)
        logits = _policy_logits(-scores, alpha_init) / max(1e-12, temp)
        p = _softmax(logits)
    else:
        p = None

    for _ in range(pop):
        if p is not None:
            # k를 임의로 뽑고(prob에서 비복원 샘플), 나머지는 0
            k = random.randint(kmin, kmax)
            chosen = np.random.choice(np.arange(m), size=k, replace=False, p=p)
            bits = [0]*m
            for i in chosen: bits[int(i)] = 1
        else:
            bits = [1 if random.random() < p_init else 0 for _ in range(m)]
            bits = _clamp_bits(bits, kmin, kmax)
        popu.append(bits)
    return popu


# --- crossover/mutation ---
def crossover_fixed(p1: Sequence[str], p2: Sequence[str], all_cands: Sequence[str], k: int, pc: float) -> Tuple[List[str], List[str]]:
    if random.random() > pc: return sorted(p1), sorted(p2)
    s1, s2 = set(p1), set(p2)
    common = list(s1 & s2)
    a_only = list(s1 - s2); random.shuffle(a_only)
    b_only = list(s2 - s1); random.shuffle(b_only)
    def build(first: List[str], second: List[str]) -> List[str]:
        child = list(common)
        for src in (first, second):
            for e in src:
                if len(child) >= k: break
                if e not in child: child.append(e)
        pool = [c for c in all_cands if c not in child]
        while len(child) < k and pool:
            x = random.choice(pool); pool.remove(x); child.append(x)
        child.sort(); return child
    return build(a_only, b_only), build(b_only, a_only)


def mutate_fixed_guided(ind: List[str], all_cands: Sequence[str], k: int, pm: float,
                        policy: Optional[Dict[str,float]], alpha: float, temp: float) -> List[str]:
    if random.random() > pm:
        return ind[:]
    closed = list(ind)
    closed_set = set(closed)
    open_edges = [e for e in all_cands if e not in closed_set]
    if k <= 0 or len(open_edges) == 0 or len(closed) == 0:
        return ind[:]
    m_swap = max(1, int(round(pm * k)))
    s_closed = np.array([policy.get(e, 0.0) if policy else 0.0 for e in closed], dtype=np.float32)
    s_open   = np.array([policy.get(e, 0.0) if policy else 0.0 for e in open_edges], dtype=np.float32)
    p_open  = _softmax(_policy_logits(+s_closed, +alpha) / max(1e-12, temp))
    idx_open  = _wsample_without_replacement(range(len(closed)), p_open, m_swap)
    to_open   = [closed[i] for i in idx_open]
    p_close = _softmax(_policy_logits(-s_open, +alpha) / max(1e-12, temp))
    idx_close = _wsample_without_replacement(range(len(open_edges)), p_close, len(to_open))
    to_close  = [open_edges[i] for i in idx_close]
    new_closed = [e for e in closed if e not in set(to_open)]
    new_closed.extend(to_close)
    if len(new_closed) > k:
        new_closed = new_closed[:k]
    return new_closed


def crossover_bits(p1: List[int], p2: List[int], pc: float) -> Tuple[List[int], List[int]]:
    if random.random() > pc: return p1[:], p2[:]
    m = len(p1); c1=[0]*m; c2=[0]*m
    for i in range(m):
        if random.random() < 0.5: c1[i]=p1[i]; c2[i]=p2[i]
        else: c1[i]=p2[i]; c2[i]=p1[i]
    return c1, c2


def mutate_bits_guided(ind: List[int], pm: float, policy: Optional[Dict[str,float]],
                       cands: List[str], kmin: int, kmax: int,
                       alpha: float, temp: float) -> List[int]:
    n = len(ind)
    x = np.array(ind, dtype=np.uint8)
    m = max(1, int(round(pm * n)))
    scores = np.array([policy.get(e, 0.0) if policy else 0.0 for e in cands], dtype=np.float32)
    idx_open  = np.where(x == 0)[0]   # 0->1 (닫기)
    idx_close = np.where(x == 1)[0]   # 1->0 (열기)
    m_close = int(round(m * (len(idx_open) / n)))
    m_open  = m - m_close
    sel_close = []
    if len(idx_open) and m_close > 0:
        logits = _policy_logits(-scores[idx_open], +alpha) / max(1e-12, temp)
        p = _softmax(logits)
        sel_close = _wsample_without_replacement(idx_open, p, m_close)
    sel_open = []
    if len(idx_close) and m_open > 0:
        logits = _policy_logits(+scores[idx_close], +alpha) / max(1e-12, temp)
        p = _softmax(logits)
        sel_open = _wsample_without_replacement(idx_close, p, m_open)
    y = x.copy()
    if sel_close: y[np.array(sel_close)] = 1
    if sel_open:  y[np.array(sel_open)]  = 0
    y = _clamp_bits(y.tolist(), kmin, kmax)  # variable 모드 K 보정
    return list(map(int, y))


# ---------------- Evaluation driver ----------------
def fingerprint_closed(closed: Sequence[str]) -> str:
    return "|".join(sorted(closed))


def eval_task(task) -> Tuple[int, float, str, List[str]]:
    (idx, closed, context) = task
    run_dir = context["outdir"] / f"g{context['gen']:03d}_i{idx:03d}"
    run_dir.mkdir(parents=True, exist_ok=True)
    add_path = run_dir / "closures.add.xml"
    write_closures_additional(add_path, closed, context["upstream_map"], begin=context["begin"], end=context["end"])
    score = run_single_sumo_and_score(
        sumo_bin=context["sumo_bin"],
        sumocfg=context["sumocfg"],
        additional=add_path,
        outdir=run_dir,
        reroute_period=context["reroute_period"],
        time_to_teleport=context["time_to_teleport"],
        time_to_teleport_highways=context["time_to_teleport_highways"],
        emit_tripinfo=context["emit_tripinfo"],
        demand_size=context.get("demand_size"),
    )
    return idx, score, str(run_dir), list(closed)


def run_ga(*, sumo_bin: str, sumocfg: str, net_path: str, protect: List[str], limit: Optional[int],
           params: GAParams, outdir: Path, auto_protect_dest: bool = True,
           demand_size: Optional[int] = None):

    random.seed(params.seed)
    np.random.seed(params.seed)  # for numpy sampling
    import_traci_sumolib()  # sanity

    outdir.mkdir(parents=True, exist_ok=True)
    summary_csv = outdir / "summary.csv"
    if not summary_csv.exists():
        with summary_csv.open("w", newline="", encoding="utf-8") as f:
            w = csv.writer(f); w.writerow(["gen","idx","k","score","closed_edges","run_dir","tripinfo"])

    protect_set = set(protect or [])
    if auto_protect_dest:
        endpoints = _extract_route_endpoints(sumocfg)
        if endpoints:
            protect_set.update(endpoints)
            print(f"자동 보호 엣지(출발/목적지) 추가: {sorted(endpoints)}")

    candidates, upstream_map, net = load_candidates(net_path, protect_set, limit)
    if params.mode == "fixed" and len(candidates) < params.k:
        raise RuntimeError(f"후보 엣지 부족: {len(candidates)} < k={params.k}")

    policy_scores = try_load_policy(params.policy_model, net, candidates) if params.gnn_usage != 'none' else None

    print(f"후보 엣지 수: {len(candidates)} (limit={limit}) | 보호 엣지: {sorted(protect_set)}")
    print(f"작업 디렉터리: {outdir}")
    policy_used = params.gnn_usage if policy_scores is not None else 'none'
    print(f"모드: {params.mode} | 정책 사용: {policy_used}")

    cache: Dict[str, float] = {}
    cache_hit = 0
    cache_miss = 0
    best_closed: Optional[List[str]] = None
    best_score = float("inf")

    # init population
    if params.mode == "fixed":
        policy_for_init = policy_scores if params.gnn_usage in ("init","both") else None
        population = init_population_fixed_guided(candidates, params.k, params.pop, policy_for_init, params.seed_ratio, params.policy_jitter)
    else:
        policy_for_init = policy_scores if params.gnn_usage in ("init","both") else None
        population = init_population_bits_guided(candidates, params.p_init, params.pop, params.kmin, params.kmax,
                                                 policy_for_init, params.policy_alpha_init, params.policy_temp)

    # generations
    for gen in range(1, params.gen+1):
        print(f"\n[세대 {gen}/{params.gen}] 평가…")
        eval_ctx = {
            "sumo_bin": sumo_bin, "sumocfg": sumocfg, "upstream_map": upstream_map,
            "begin": params.begin, "end": params.end, "reroute_period": params.reroute_period,
            "outdir": outdir, "gen": gen,
            "time_to_teleport": params.time_to_teleport,
            "time_to_teleport_highways": params.time_to_teleport_highways,
            "emit_tripinfo": params.emit_tripinfo,
            "demand_size": demand_size,
        }

        # build tasks (use cache)
        tasks = []
        closures_for_eval = []
        cached_scores = {}
        if params.mode == "fixed":
            for i, ind in enumerate(population):
                closed = ind
                key = fingerprint_closed(closed)
                closures_for_eval.append(closed)
                if key in cache:
                    cached_scores[i] = cache[key]
                    cache_hit += 1
                else:
                    tasks.append((i, closed, eval_ctx))
                    cache_miss += 1
        else:
            for i, bits in enumerate(population):
                closed = [eid for eid,b in zip(candidates, bits) if b==1]
                closures_for_eval.append(closed)
                key = fingerprint_closed(closed)
                if key in cache:
                    cached_scores[i] = cache[key]
                else:
                    tasks.append((i, closed, eval_ctx))
                    cache_miss += 1

        results = [None] * len(population)  # type: ignore
        for i, sc in cached_scores.items():
            results[i] = (i, sc, str(outdir / f"g{gen:03d}_i{i:03d}"), closures_for_eval[i])

        if tasks:
            if params.jobs > 1:
                from multiprocessing import Pool
                with Pool(processes=params.jobs) as pool:
                    for res in pool.imap_unordered(eval_task, tasks):
                        results[res[0]] = res
            else:
                for t in tasks:
                    res = eval_task(t)
                    results[res[0]] = res
            for r in results:
                i, sc, _, closed = r  # type: ignore
                cache[fingerprint_closed(closed)] = sc  # type: ignore
        
        # log + best
        with summary_csv.open("a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            for idx, sc, run_dir, closed in results:  # type: ignore
                k = len(closed)
                tripinfo = str(Path(run_dir) / "tripinfo.xml")
                w.writerow([gen, idx, k, sc, ";".join(closed), run_dir, tripinfo])
                print(f"  개체 {idx:02d}: k={k:02d} -> {sc:.3f} | 닫힘: {closed}")
                if sc < best_score:
                    best_score = sc; best_closed = list(closed)

        gen_best = min(r[1] for r in results)  # type: ignore
        print(f"세대 {gen} 최고: {gen_best:.3f} | 전역 최고: {best_score:.3f} {best_closed}")

        # --- selection (tournament) ---
        scores = [r[1] for r in results]  # type: ignore
        with open(outdir / "gen_best.csv", "a", encoding="utf-8") as w:
            w.write(f"{gen},{gen_best:.6f}\n")

        def tournament():
            tsize = max(2, min(5, len(population)//6 or 2))
            idxs = random.sample(range(len(population)), tsize)
            best_idx = min(idxs, key=lambda j: scores[j])
            return population[best_idx][:] if params.mode=="fixed" else population[best_idx][:]

        new_pop = []
        elite_idx = min(range(len(population)), key=lambda j: scores[j])
        new_pop.append(population[elite_idx][:])

        while len(new_pop) < params.pop:
            p1, p2 = tournament(), tournament()
            if params.mode == "fixed":
                c1, c2 = crossover_fixed(p1, p2, candidates, params.k, params.pc)
                policy_for_mutate = policy_scores if params.gnn_usage in ("mutation","both") else None
                c1 = mutate_fixed_guided(c1, candidates, params.k, params.pm, policy_for_mutate,
                                         params.policy_alpha_mut, params.policy_temp)
                if len(new_pop) < params.pop: new_pop.append(c1)
                policy_for_mutate = policy_scores if params.gnn_usage in ("mutation","both") else None
                c2 = mutate_fixed_guided(c2, candidates, params.k, params.pm, policy_for_mutate,
                                         params.policy_alpha_mut, params.policy_temp)
                if len(new_pop) < params.pop: new_pop.append(c2)
            else:
                c1, c2 = crossover_bits(p1, p2, params.pc)
                policy_for_mutate = policy_scores if params.gnn_usage in ("mutation","both") else None
                c1 = mutate_bits_guided(c1, params.pm, policy_for_mutate, candidates, params.kmin, params.kmax,
                                        params.policy_alpha_mut, params.policy_temp)
                if len(new_pop) < params.pop: new_pop.append(c1)
                policy_for_mutate = policy_scores if params.gnn_usage in ("mutation","both") else None
                c2 = mutate_bits_guided(c2, params.pm, policy_for_mutate, candidates, params.kmin, params.kmax,
                                        params.policy_alpha_mut, params.policy_temp)
                if len(new_pop) < params.pop: new_pop.append(c2)

        population = new_pop[:params.pop]
    
    # write best
    best_file = outdir / "best.txt"
    with best_file.open("w", encoding="utf-8") as f:
        f.write(f"best_score={best_score:.6f}\n")
        f.write("closed_edges=" + (" ".join(best_closed) if best_closed else "") + "\n")
    print("\n=== 최종 결과 ===")
    print(f"베스트 점수: {best_score:.3f}")
    print(f"닫을 엣지: {best_closed}")
    print(f"산출물 폴더: {outdir}")
    total_lookups = cache_hit + cache_miss
    hit_ratio = cache_hit / total_lookups if total_lookups > 0 else 0.0
    print(f"Cache hits: {cache_hit}, misses: {cache_miss}, "
      f"hit ratio: {hit_ratio:.3f}")



def parse_args():
    p = argparse.ArgumentParser(description="GA + Policy-GNN for SUMO edge closure (avg trip time only)")
    p.add_argument("--sumocfg", required=True)
    p.add_argument("--net", required=True)
    p.add_argument("--sumo-bin", default=None)

    p.add_argument("--gnn-usage", choices=["none","init","mutation","both"], default="both", help="정책 GNN 사용 범위")
    p.add_argument("--mode", choices=["fixed","variable"], default="variable")
    p.add_argument("--k", type=int, default=3)
    p.add_argument("--kmin", type=int, default=0)
    p.add_argument("--kmax", type=int, default=8)
    p.add_argument("--p-init", dest="p_init", type=float, default=0.05)
    p.add_argument("--pop", type=int, default=24)
    p.add_argument("--gen", type=int, default=10)
    p.add_argument("--pc", type=float, default=0.9)
    p.add_argument("--pm", type=float, default=0.1)
    p.add_argument("--jobs", type=int, default=1)
    p.add_argument("--protect", nargs=argparse.REMAINDER, default=[],
                   help="Protected edge IDs. NOTE: keep this option LAST; it will consume all remaining tokens (allows IDs like -E41).")
    p.add_argument("--protect-str", type=str, default="")
    p.add_argument("--no_auto_protect_dest", action="store_true", help="Disable automatic protection of route start/end edges")
    p.add_argument("--limit", type=int, default=0, help="0이면 전체")
    p.add_argument("--begin", type=int, default=0)
    p.add_argument("--end", type=int, default=86400)
    p.add_argument("--reroute-period", type=int, default=30)
    p.add_argument("--outdir", default=str(Path.cwd() / "output"))
    p.add_argument("--seed", type=int, default=42)
    # policy
    p.add_argument("--policy-model", default=None, help="policy_model.pt 경로(없으면 정책 미사용)")
    p.add_argument("--seed-ratio", dest="seed_ratio", type=float, default=0.5, help="초기개체 중 정책 시드 비율 (fixed 모드)")
    p.add_argument("--policy-alpha-init", type=float, default=+1.0, help="초기화에서 정책 점수의 부호/세기")
    p.add_argument("--policy-alpha-mut",  type=float, default=+1.0, help="변이에서 정책 점수의 부호/세기")
    p.add_argument("--policy-temp",       type=float, default=1.0,  help="softmax 온도(클수록 균등)")
    p.add_argument("--policy-jitter",     type=int,   default=2,    help="fixed 모드: 시드 당 랜덤 치환 수")

    # Teleport / tripinfo
    p.add_argument("--time-to-teleport", type=int, default=-1,
                   help="SUMO --time-to-teleport 전달값. -1이면 텔레포트 완전 비활성화")
    p.add_argument("--time-to-teleport-highways", type=int, default=-1,
                   help="SUMO --time-to-teleport.highways 전달값")
    p.add_argument("--emit-tripinfo", action="store_true",
                   help="추가 tripinfo 옵션(기본적으로는 점수 계산 위해 tripinfo 출력)")
    p.add_argument(
        "--demand-size", type=int, default=None,
        help="전체 수요(차량 수). 설정하면, 이 수보다 적게 나타나거나 하나라도 미도착이면 패널티로 처리."
    )
    args = p.parse_args()

    # Normalize protect list from either --protect (REMAINDER) or --protect-str.
    prot: list[str] = []
    if getattr(args, "protect", None):
        prot.extend(list(args.protect))
        # allow user to write: --protect -- -E41 E35 ...
        if prot and prot[0] == "--":
            prot = prot[1:]
    if getattr(args, "protect_str", ""):
        prot.extend(str(args.protect_str).split())
    args.protect = prot
    return args
    

def main():
    args = parse_args()
    sumo_bin = resolve_sumo_bin(args.sumo_bin)
    outdir = Path(args.outdir)
    limit = None if args.limit == 0 else args.limit

    params = GAParams(
        gnn_usage=args.gnn_usage,
        mode=args.mode, k=args.k, kmin=args.kmin, kmax=args.kmax, p_init=args.p_init,
        pc=args.pc, pm=args.pm, pop=args.pop, gen=args.gen, jobs=args.jobs,
        begin=args.begin, end=args.end, reroute_period=args.reroute_period, seed=args.seed,
        policy_model=args.policy_model, seed_ratio=args.seed_ratio,
        policy_alpha_init=args.policy_alpha_init, policy_alpha_mut=args.policy_alpha_mut,
        policy_temp=args.policy_temp, policy_jitter=args.policy_jitter,
        time_to_teleport=args.time_to_teleport,
        time_to_teleport_highways=args.time_to_teleport_highways,
        emit_tripinfo=bool(args.emit_tripinfo),
    )

    start = time.perf_counter()

    run_ga(
        sumo_bin=sumo_bin, sumocfg=args.sumocfg, net_path=args.net,
        protect=args.protect, limit=limit, params=params, outdir=outdir,
        auto_protect_dest=(not getattr(args, "no_auto_protect_dest", False)),
        demand_size=args.demand_size,
    )

    elapsed = time.perf_counter() - start
    print(f"Elapsed: {elapsed:.3f} sec")


if __name__ == "__main__":
    main()

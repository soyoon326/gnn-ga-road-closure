# train_policy_gnn.py
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse, random, os
from pathlib import Path
import numpy as np
import torch
from policy_gnn_model import PolicyGNN
import time

def split_sets(samps):
    ys = np.array([float(s['y']) for s in samps], dtype=np.float64)
    order = np.argsort(ys)
    k = max(1, len(samps)//5)
    best = [samps[int(i)] for i in order[:k].tolist()]
    worst = [samps[int(i)] for i in order[-k:].tolist()]
    return best, worst
def set_score_from_edge_scores(edge_scores: torch.Tensor, mask: torch.Tensor, reduce: str = "mean") -> torch.Tensor:
    # edge_scores: [E] or [E,1], mask: [E]
    s = edge_scores.view(-1)
    m = mask.view(-1)
    if reduce == "sum":
        return (s * m).sum()
    denom = m.sum().clamp(min=1.0)
    return (s * m).sum() / denom

def load_blob(path: Path):
    return torch.load(path, map_location="cpu")

def main():
    start = time.perf_counter()

    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="output_policy")
    ap.add_argument("--epochs", type=int, default=80)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--margin", type=float, default=1.0) # 5.0
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--val-split", type=float, default=0.15)
    ap.add_argument("--model-out", type=str, default=None,
                    help="Path to save the best checkpoint (default: <data>/policy_model.pt)")
    ap.add_argument("--deterministic", action="store_true",
                    help="Enable deterministic (reproducible) training; may be slower on GPU")
    ap.add_argument("--device", type=str, default="auto",
                    choices=["auto","cpu","cuda"],
                    help="Training device (default: auto)")
    args = ap.parse_args()
    # Reproducibility
    os.environ["PYTHONHASHSEED"] = str(args.seed)
    torch.manual_seed(args.seed); np.random.seed(args.seed); random.seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    if args.deterministic:
        # For CUDA deterministic behavior where possible
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        try:
            torch.use_deterministic_algorithms(True)
        except Exception:
            pass
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        # Avoid TF32 changing numerics across GPUs/drivers
        if hasattr(torch.backends, "cuda") and hasattr(torch.backends.cuda, "matmul"):
            torch.backends.cuda.matmul.allow_tf32 = False
        if hasattr(torch.backends, "cudnn"):
            torch.backends.cudnn.allow_tf32 = False


    outdir = Path(args.data)
    blob = load_blob(outdir/"graph_policy.pt")
    edge_index = blob["edge_index"]
    x_node = blob["x_node"]
    edge_attr = blob["edge_attr"]
    samples = load_blob(outdir/"dataset_policy.pt")

    idx = np.random.permutation(len(samples))
    nval = max(200, int(args.val_split * len(samples)))
    val_idx, train_idx = idx[:nval], idx[nval:]
    samples_tr = [samples[int(i)] for i in train_idx.tolist()]
    samples_va = [samples[int(i)] for i in val_idx.tolist()]


    in_node = x_node.size(1); in_edge = edge_attr.size(1)
    model = PolicyGNN(in_node, in_edge, hid=256, heads=4)
    if args.device == "cpu":
        device = torch.device("cpu")
    elif args.device == "cuda":
        if not torch.cuda.is_available():
            raise SystemExit("Requested --device cuda but CUDA is not available.")
        device = torch.device("cuda")
    else:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


    model.to(device); x_node = x_node.to(device); edge_index = edge_index.to(device); edge_attr = edge_attr.to(device)

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)

    def split_sets(samps, qlo=0.1, qhi=0.9): # 0.3, 0.7
        ys = np.array([float(s['y']) for s in samps], dtype=np.float64)
        lo, hi = np.quantile(ys, qlo), np.quantile(ys, qhi)
        best  = [s for s, y in zip(samps, ys) if y <= lo]
        worst = [s for s, y in zip(samps, ys) if y >= hi]
        return best, worst

    best_val = float("inf")
    for ep in range(1, args.epochs+1):
        model.train()
        best, worst = split_sets(samples_tr)
        tot=0.0; n=0
        for _ in range(max(64, len(samples)//2)):
            sa = random.choice(best); sb = random.choice(worst)
            scores = model(x_node, edge_index, edge_attr).squeeze(-1)
            sa_mask = sa['mask'].to(device).float()  # best
            sb_mask = sb['mask'].to(device).float()  # worst

            pred_a = set_score_from_edge_scores(scores, sa_mask)
            pred_b = set_score_from_edge_scores(scores, sb_mask)

            # 마진 랭킹: worst - best >= margin
            loss = torch.clamp(args.margin - (pred_b - pred_a), min=0.0)
            opt.zero_grad(); loss.backward(); opt.step()
            tot += float(loss.item()); n += 1
        tr = tot/max(1,n)

        model.eval()
        with torch.no_grad():
            best, worst = split_sets(samples_va)
            tot = 0.0; n = 0
            for _ in range(200):
                sa = random.choice(best); sb = random.choice(worst)
                scores = model(x_node, edge_index, edge_attr).squeeze(-1)
                sa_mask = sa['mask'].to(device).float()
                sb_mask = sb['mask'].to(device).float()

                pred_a = set_score_from_edge_scores(scores, sa_mask)
                pred_b = set_score_from_edge_scores(scores, sb_mask)

                loss = torch.clamp(args.margin - (pred_b - pred_a), min=0.0)
                tot += float(loss.item()); n += 1
            va = tot / max(1, n)
        print(f"[{ep:03d}] train {tr:.3f} | val {va:.3f}")
        if va < best_val:
            best_val = va
            save_path = Path(args.model_out) if args.model_out else (outdir/'policy_model.pt')
            torch.save({'state_dict': model.state_dict(), 'in_node': in_node, 'in_edge': in_edge}, save_path)
    print('Saved', save_path)

    elapsed = time.perf_counter() - start
    print(f"Elapsed: {elapsed:.3f} sec")

if __name__ == "__main__":
    main()

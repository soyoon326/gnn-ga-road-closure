# make_policy_dataset.py (v3)
# -*- coding: utf-8 -*-
"""
Deterministic(ish) policy dataset generator for GNN.

v2 changes (vs your original):
- Adds torch seed + PYTHONHASHSEED
- Adds --part-id to make parallel shards reproducible and non-overlapping
- Adds deterministic SUMO seeding per-sample via --sumo-seed-base (+ part-id, sample index)
- Uses a dedicated NumPy RNG (default_rng) instead of global np.random
- Deletes stale tripinfo.xml before each SUMO run (prevents reading old results on failure)
- Uses a unique TraCI label per run (safer in parallel / repeated calls)
"""
from __future__ import annotations
import argparse, os, random, re, xml.etree.ElementTree as ET, shutil
from pathlib import Path
from typing import List, Dict, Optional, Tuple

import numpy as np
import torch


def ensure_sumo_tools_on_path():
    sh = os.environ.get("SUMO_HOME")
    if sh:
        tools = str(Path(sh) / "tools")
        import sys
        if tools not in sys.path:
            sys.path.append(tools)


def import_traci_sumolib():
    ensure_sumo_tools_on_path()
    import traci  # type: ignore
    from sumolib.net import readNet
    return traci, readNet


def set_all_seeds(seed: int) -> None:
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)  # for any legacy calls
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def build_graph(net_path: str):
    _, readNet = import_traci_sumolib()
    net = readNet(net_path)
    nodes = net.getNodes()
    node_id_map = {n.getID(): i for i, n in enumerate(nodes)}
    N = len(nodes)

    deg_in = np.zeros((N, 1), dtype=np.float32)
    deg_out = np.zeros((N, 1), dtype=np.float32)
    is_tls = np.zeros((N, 1), dtype=np.float32)

    for n in nodes:
        i = node_id_map[n.getID()]
        deg_in[i, 0] = len([e for e in n.getIncoming() if not e.getID().startswith(":")])
        deg_out[i, 0] = len([e for e in n.getOutgoing() if not e.getID().startswith(":")])
        is_tls[i, 0] = 1.0 if n.getType() == "traffic_light" else 0.0

    x_node = np.concatenate([deg_in, deg_out, is_tls], axis=1)

    edges = [
        e for e in net.getEdges()
        if not e.getID().startswith(":")
        and (e.getFunction() or "") != "internal"
        and len(e.getLanes()) > 0
    ]
    edge_id_map = {e.getID(): i for i, e in enumerate(edges)}
    E = len(edges)

    src = np.array([node_id_map[e.getFromNode().getID()] for e in edges], dtype=np.int64)
    dst = np.array([node_id_map[e.getToNode().getID()] for e in edges], dtype=np.int64)
    edge_index = np.stack([src, dst], axis=0)

    length = np.array([e.getLength() for e in edges], dtype=np.float32).reshape(E, 1)
    lanes = np.array([len(e.getLanes()) for e in edges], dtype=np.float32).reshape(E, 1)
    speed = np.array([e.getSpeed() for e in edges], dtype=np.float32).reshape(E, 1)
    priority = np.array([(e.getPriority() or 0) for e in edges], dtype=np.float32).reshape(E, 1)
    from_tls = is_tls[src].astype(np.float32)
    to_tls = is_tls[dst].astype(np.float32)

    edge_attr = np.concatenate([length, lanes, speed, priority, from_tls, to_tls], axis=1).astype(np.float32)
    return edge_index, x_node, edge_attr, node_id_map, edge_id_map


def build_upstream_map(net_path: str) -> Dict[str, List[str]]:
    _, readNet = import_traci_sumolib()
    net = readNet(net_path)
    edges = [
        e for e in net.getEdges()
        if not e.getID().startswith(":")
        and (e.getFunction() or "") != "internal"
        and len(e.getLanes()) > 0
    ]
    m: Dict[str, List[str]] = {}
    for e in edges:
        up = []
        for ine in e.getFromNode().getIncoming():
            if ine.getID().startswith(":"):
                continue
            up.append(ine.getID())
        m[e.getID()] = up if up else [e.getID()]
    return m


def _split_route_files(value: str) -> List[str]:
    value = (value or "").strip()
    if not value:
        return []
    # SUMO route-files can be separated by spaces, ';', or ',' (avoid splitting inside paths with spaces)
    parts = re.split(r"[;,]\s*|\s+", value)
    return [p for p in parts if p]


def extract_route_endpoints(sumocfg_path: str) -> List[str]:
    """
    Extract OD endpoint edges (from/to) referenced in SUMO route files.
    Supports <flow from/to>, <trip from/to>, <route edges>, and <vehicle><route edges>.
    Returns a list of edge IDs.
    """
    sumocfg = Path(sumocfg_path)
    try:
        cfg_root = ET.parse(sumocfg).getroot()
    except Exception:
        return []
    rf = cfg_root.find(".//route-files")
    if rf is None:
        return []
    value = rf.get("value") or ""
    files = _split_route_files(value)
    if not files:
        return []
    base = sumocfg.parent

    endpoints: set[str] = set()
    for f in files:
        p = Path(f)
        if not p.is_absolute():
            p = (base / f).resolve()
        try:
            rroot = ET.parse(p).getroot()
        except Exception:
            continue

        for fl in rroot.iter("flow"):
            frm = fl.get("from"); to = fl.get("to")
            if frm: endpoints.add(frm)
            if to: endpoints.add(to)

        for tr in rroot.iter("trip"):
            frm = tr.get("from"); to = tr.get("to")
            if frm: endpoints.add(frm)
            if to: endpoints.add(to)

        for r in rroot.iter("route"):
            edges = (r.get("edges") or "").split()
            if edges:
                endpoints.add(edges[0]); endpoints.add(edges[-1])

        for v in rroot.iter("vehicle"):
            rr = v.find("route")
            if rr is not None:
                edges = (rr.get("edges") or "").split()
                if edges:
                    endpoints.add(edges[0]); endpoints.add(edges[-1])

    return sorted(endpoints)


def write_addfile(path: Path, closed_edges: List[str], upstream_map: Dict[str, List[str]]):
    add = ET.Element("additional")
    if closed_edges:
        notify = set()
        for e in closed_edges:
            notify.update(upstream_map.get(e, [e]))
        if notify:
            rr = ET.SubElement(add, "rerouter", attrib={
                "id": "rr_close",
                "edges": " ".join(sorted(notify)),
                "probability": "1.0",
            })
            iv = ET.SubElement(rr, "interval", attrib={"begin": "0", "end": "86400"})
            for e in closed_edges:
                ET.SubElement(iv, "closingReroute", attrib={"id": e})
    ET.ElementTree(add).write(path, encoding="UTF-8", xml_declaration=True)


def run_sumo_score(
    sumo_bin: str,
    sumocfg: str,
    addfile: Path,
    workdir: Path,
    *,
    sumo_seed: Optional[int] = None,
    reroute_period: int = 30,
    step_limit: int = 200000,
    time_to_teleport: int = -1,
    time_to_teleport_highways: int = -1,
) -> float:
    traci, _ = import_traci_sumolib()

    tripinfo = workdir / "tripinfo.xml"
    if tripinfo.exists():
        # prevent accidental reuse of stale outputs
        try:
            tripinfo.unlink()
        except Exception:
            pass

    cmd = [
        sumo_bin, "-c", sumocfg, "-a", str(addfile),
        "--no-step-log", "true",
        "--tripinfo-output", str(tripinfo),
        "--device.rerouting.probability", "1.0",
        "--device.rerouting.period", str(reroute_period),
        "--duration-log.disable", "true",
        "--time-to-teleport", str(time_to_teleport),
        "--time-to-teleport.highways", str(time_to_teleport_highways),
    ]
    if sumo_seed is not None:
        cmd += ["--seed", str(int(sumo_seed))]

    label = f"policy_ds_{os.getpid()}_{sumo_seed if sumo_seed is not None else 'x'}"
    try:
        traci.start(cmd, label=label)
        conn = traci.getConnection(label)
        step = 0
        while conn.simulation.getMinExpectedNumber() > 0 and step < step_limit:
            conn.simulationStep()
            step += 1
        conn.close()

        if not tripinfo.exists():
            return 1e12

        durs = []
        root = ET.parse(tripinfo).getroot()
        for ev in root.iter("tripinfo"):
            ds = ev.attrib.get("duration")
            if ds is None:
                continue
            d = float(ds)
            if d >= 0:
                durs.append(d)
        if not durs:
            return 1e12
        return float(np.mean(durs))
    except Exception:
        return 1e12  # worst penalty
    finally:
        try:
            traci.close(False)
        except Exception:
            pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sumocfg", required=True)
    ap.add_argument("--net", required=True)
    ap.add_argument("--outdir", default="output_policy")
    ap.add_argument("--samples", type=int, default=600)
    ap.add_argument("--kmax", type=int, required=True)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--protect", nargs="*", default=[])
    grp = ap.add_mutually_exclusive_group()
    grp.add_argument("--auto-protect-endpoints", dest="auto_protect_endpoints", action="store_true",
                     help="Exclude OD endpoints (from/to edges in route-files) from candidate closures.")
    grp.add_argument("--no-auto-protect-endpoints", dest="auto_protect_endpoints", action="store_false",
                     help="Do not exclude OD endpoints from candidates.")
    ap.set_defaults(auto_protect_endpoints=True)

    ap.add_argument("--sumo-bin", default=None)

    # Reproducibility controls
    ap.add_argument("--seed", type=int, default=42, help="Base RNG seed for sampling closures.")
    ap.add_argument("--part-id", type=int, default=0, help="Shard id (used to offset RNG and SUMO seeds).")
    ap.add_argument("--sumo-seed-base", type=int, default=100000, help="Base SUMO seed; per-sample seed = base + part_id*1e6 + sample_idx.")
    ap.add_argument("--reroute-period", type=int, default=30)

    ap.add_argument("--time-to-teleport", type=int, default=-1)
    ap.add_argument("--time-to-teleport-highways", type=int, default=-1)

    args = ap.parse_args()

    if args.sumo_bin:
        sumo_bin = args.sumo_bin
    else:
        cand = shutil.which("sumo")
        if not cand:
            raise RuntimeError("sumo 실행파일을 찾지 못함. --sumo-bin 지정 필요")
        sumo_bin = cand

    # Make shard-specific seed (so part0/part1 don't duplicate)
    shard_seed = int(args.seed) + int(args.part_id) * 10007
    set_all_seeds(shard_seed)

    # Dedicated RNG for reproducible sampling (avoid global state)
    rng = np.random.default_rng(shard_seed)

    edge_index, x_node, edge_attr, node_map, edge_map = build_graph(args.net)
    E = edge_attr.shape[0]

    protect = set(args.protect or [])
    endpoints: List[str] = []
    if bool(getattr(args, "auto_protect_endpoints", True)):
        endpoints = extract_route_endpoints(args.sumocfg)
        # Keep only endpoints that exist as edges in this net
        endpoints_set = {e for e in endpoints if e in edge_map}
        protect |= endpoints_set
        if endpoints_set:
            print(f"[dataset] auto-protect endpoints: {len(endpoints_set)} -> {sorted(list(endpoints_set))}")

    edge_ids = [eid for eid in edge_map.keys() if eid not in protect]

    if args.limit and len(edge_ids) > args.limit:
        rng.shuffle(edge_ids)
        edge_ids = edge_ids[:args.limit]

    edge_ids_sorted = sorted(edge_ids)
    upstream_map = build_upstream_map(args.net)

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    torch.save({
        "edge_index": torch.tensor(edge_index, dtype=torch.long),
        "x_node": torch.tensor(x_node, dtype=torch.float32),
        "edge_attr": torch.tensor(edge_attr, dtype=torch.float32),
        "edge_ids": edge_ids_sorted,
        "edge_map": edge_map,
        "node_map": node_map,
    }, outdir / "graph_policy.pt")

    samples = []
    for s in range(int(args.samples)):
        k = int(rng.integers(0, min(int(args.kmax), len(edge_ids_sorted)) + 1))
        if k > 0:
            closed = set(rng.choice(edge_ids_sorted, size=k, replace=False).tolist())
        else:
            closed = set()

        mask = np.zeros((E,), dtype=np.float32)
        for eid in closed:
            mask[edge_map[eid]] = 1.0

        run_dir = outdir / f"sim_{s:04d}"
        run_dir.mkdir(exist_ok=True)

        addfile = run_dir / "closures.add.xml"
        write_addfile(addfile, sorted(list(closed)), upstream_map)

        # Deterministic SUMO seed per-sample
        sumo_seed = int(args.sumo_seed_base) + int(args.part_id) * 1_000_000 + s

        y = run_sumo_score(
            sumo_bin, args.sumocfg, addfile, run_dir,
            sumo_seed=sumo_seed,
            reroute_period=int(args.reroute_period),
            time_to_teleport=int(args.time_to_teleport),
            time_to_teleport_highways=int(args.time_to_teleport_highways),
        )

        samples.append({"mask": torch.tensor(mask), "y": torch.tensor(float(y)), "closed_edges": sorted(list(closed))})

    torch.save(samples, outdir / "dataset_policy.pt")
    meta = {
        "seed": int(args.seed),
        "part_id": int(args.part_id),
        "shard_seed": shard_seed,
        "sumo_seed_base": int(args.sumo_seed_base),
        "samples": int(args.samples),
        "kmax": int(args.kmax),
        "protect": sorted(list(protect)),
        "auto_protect_endpoints": bool(getattr(args, "auto_protect_endpoints", True)),
        "endpoints": endpoints,
        "sumocfg": str(args.sumocfg),
        "net": str(args.net),
    }
    (outdir / "dataset_meta.json").write_text(
        __import__("json").dumps(meta, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print(f"Saved graph + {len(samples)} samples to: {outdir}")
    print(f"Meta: {outdir/'dataset_meta.json'}")


if __name__ == "__main__":
    main()

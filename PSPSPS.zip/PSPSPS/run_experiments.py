"""
run_experiments.py
Run SUMO+GA(+GNN) experiments without editing scripts for every new OD/demand/seed.

This script is intentionally "boring":
- reads experiments.json
- runs steps: dataset -> merge -> train -> ga -> analyze
- everything is driven by config fields

Typical usage:
  python run_experiments.py --config experiments.json --name A_k4_2od_x1.0

Run only GA+analyze using an existing trained model:
  python run_experiments.py --config experiments.json --name A_k4_2od_x1.0 --steps ga analyze

Dry-run (prints commands only):
  python run_experiments.py --config experiments.json --name A_k4_2od_x1.0 --dry-run
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List


def _q(s: str) -> str:
    # For printing only; do not use for shell execution.
    if " " in s or "\t" in s:
        return f'"{s}"'
    return s


def run_cmd(cmd: List[str], cwd: Path, stdout_path: Path | None, dry_run: bool) -> None:
    printable = " ".join(_q(x) for x in cmd)
    print(f"[CMD] (cwd={cwd}) {printable}")
    if dry_run:
        return

    cwd.mkdir(parents=True, exist_ok=True)
    if stdout_path is None:
        subprocess.run(cmd, cwd=str(cwd), check=True)
        return

    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    with open(stdout_path, "a", encoding="utf-8", errors="ignore") as f:
        # merge stderr into stdout for easy debugging
        subprocess.run(cmd, cwd=str(cwd), stdout=f, stderr=subprocess.STDOUT, check=True)


def load_config(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def get_experiment(cfg: Dict[str, Any], name: str) -> Dict[str, Any]:
    for exp in cfg.get("experiments", []):
        if exp.get("name") == name:
            return exp
    names = [e.get("name") for e in cfg.get("experiments", [])]
    raise KeyError(f"Experiment '{name}' not found. Available: {names}")


def as_list(x: Any) -> List[Any]:
    if x is None:
        return []
    if isinstance(x, list):
        return x
    return [x]


import subprocess
import time

def step_dataset(exp, root: Path, python_exe: str, dry_run: bool) -> None:
    out_policy = root / exp["out_policy"]
    out_policy.mkdir(parents=True, exist_ok=True)

    parts = int(exp.get("parts", 8))
    parallel_parts = int(exp.get("parallel_parts", 4))
    samples_per_part = int(exp.get("samples_per_part", 125))

    sumo_bin = exp["sumo_bin"]
    sumocfg = root / exp["sumocfg"]
    net = root / exp["net"]
    kmax = int(exp["kmax"])
    protect = exp.get("protect", [])

    dataset_seed = int(exp.get("dataset_seed", 1234))
    sumo_seed_base = int(exp.get("sumo_seed_base", 100000))

    procs = []  # (Popen, logfile_handle)

    def start_one(part_id: int):
        part_dir = out_policy / f"part{part_id}"
        part_dir.mkdir(parents=True, exist_ok=True)
        log_path = part_dir / "dataset.log"

        cmd = [
            python_exe, "py\\make_policy_dataset.py",
            "--sumo-bin", str(sumo_bin),
            "--sumocfg", str(sumocfg),
            "--net", str(net),
            "--outdir", str(part_dir),
            "--samples", str(samples_per_part),
            "--kmax", str(kmax),
            "--seed", str(dataset_seed),                
            "--part-id", str(part_id),                  
            "--sumo-seed-base", str(sumo_seed_base),    
        ]
        if protect:
            cmd += ["--protect=" + " ".join(protect)]

        if dry_run:
            print("DRY:", " ".join(cmd))
            return None, None

        lf = open(log_path, "w", encoding="utf-8")
        p = subprocess.Popen(cmd, cwd=str(root), stdout=lf, stderr=subprocess.STDOUT)
        return p, lf


    next_part = 0
    while next_part < parts or procs:

        while next_part < parts and len(procs) < parallel_parts:
            p, lf = start_one(next_part)
            if p is not None:
                procs.append((p, lf))
            next_part += 1

        if dry_run:
            break

        still = []
        finished_any = False
        for p, lf in procs:
            ret = p.poll()
            if ret is None:
                still.append((p, lf))
            else:
                finished_any = True
                lf.close()
                if ret != 0:
                    raise RuntimeError(f"make_policy_dataset failed (exit {ret})")
        procs = still

        if not finished_any:
            time.sleep(0.2)




def step_merge(exp: Dict[str, Any], root: Path, python_exe: str, dry_run: bool) -> None:
    out_policy = root / exp["out_policy"]
    parts = int(exp.get("parts", 8))
    cmd = [python_exe, "merge_policy_parts.py", "--root", str(out_policy), "--parts", str(parts)]
    run_cmd(cmd, cwd=root, stdout_path=out_policy / "merge.log", dry_run=dry_run)

def step_train(exp: Dict[str, Any], root: Path, python_exe: str, dry_run: bool) -> None:
    out_policy = root / exp["out_policy"]
    epochs = int(exp.get("epochs", 60))

    train_seed = int(exp.get("train_seed", 42))
    deterministic = bool(exp.get("train_deterministic", True))
    device = str(exp.get("train_device", "cpu"))

    model_out = root / exp.get("policy_model", str(Path(exp["out_policy"]) / "policy_model.pt"))

    cmd = [
        python_exe, "py\\train_policy_gnn.py",
        "--data", str(out_policy),
        "--epochs", str(epochs),
        "--seed", str(train_seed),
        "--device", device,
        "--model-out", str(model_out),
    ]
    if deterministic:
        cmd.append("--deterministic")

    run_cmd(cmd, cwd=root, stdout_path=out_policy / "train.log", dry_run=dry_run)

def step_ga(exp: Dict[str, Any], root: Path, python_exe: str, dry_run: bool) -> None:
    sumocfg = str(root / exp["sumocfg"])
    net = str(root / exp["net"])
    sumo_bin = str(exp.get("sumo_bin", "")) or str(root / exp.get("sumo_bin_rel", ""))
    kmax = int(exp["kmax"])
    kmin = int(exp.get("kmin", 0))
    pop = int(exp.get("pop", 24))
    gen = int(exp.get("gen", 15))
    jobs = int(exp.get("jobs", 8))
    demand_size = int(exp.get("demand_size", 1000))
    protect = as_list(exp.get("protect", []))

    out_policy = root / exp["out_policy"]
    policy_model = exp.get("policy_model")
    if not policy_model:
        policy_model = str(out_policy / "policy_model.pt")
    else:
        policy_model = str(root / policy_model) if not Path(policy_model).is_absolute() else str(policy_model)

    runs_root = root / exp["runs_root"]

    seeds = as_list(exp.get("seeds", list(range(10))))
    modes = as_list(exp.get("modes", ["both", "init", "mutation", "none"]))
    parallel_runs = int(exp.get("parallel_runs", 1))  # keep default 1 unless you know your machine can handle more

    print(f"[ga] modes={modes} seeds={seeds} parallel_runs={parallel_runs} runs_root={runs_root}")

    def one_run(mode: str, seed: int) -> None:
        outdir = runs_root / f"{mode}_seed{seed}"
        log = outdir / "run.log"
        cmd = [
            python_exe, "py\\ga_edge_closure_gnn_policy.py",
            "--sumocfg", sumocfg, "--net", net, "--sumo-bin", sumo_bin,
            "--gnn-usage", mode, "--mode", "variable",
            "--kmin", str(kmin), "--kmax", str(kmax),
            "--pop", str(pop), "--gen", str(gen), "--jobs", str(jobs),
            "--policy-model", policy_model,
            "--time-to-teleport", "-1", "--time-to-teleport-highways", "-1",
            "--outdir", str(outdir), "--seed", str(seed),
            "--demand-size", str(demand_size),
        ]
        if protect:
            cmd += ["--protect"] + [str(p) for p in protect]
        run_cmd(cmd, cwd=root, stdout_path=log, dry_run=dry_run)

    # schedule runs (thread pool just to overlap I/O; keep it small)
    with ThreadPoolExecutor(max_workers=max(1, parallel_runs)) as ex:
        futs = [ex.submit(one_run, mode, int(seed)) for mode in modes for seed in seeds]
        for fut in as_completed(futs):
            fut.result()


def step_analyze(exp: Dict[str, Any], root: Path, python_exe: str, dry_run: bool) -> None:
    runs_root = root / exp["runs_root"]
    modes = as_list(exp.get("modes", ["both", "init", "mutation", "none"]))
    jobs = int(exp.get("analyze_jobs", 4))
    cmd = [
        python_exe, "py\\analyze_runs.py",
        "--root", str(runs_root),
        "--modes", *[str(m) for m in modes],
        "--select", "best",
        "--jobs", str(jobs),
    ]
    run_cmd(cmd, cwd=root, stdout_path=runs_root / "analyze.log", dry_run=dry_run)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True, help="Path to experiments.json")
    ap.add_argument("--name", required=True, help="Experiment name (matches experiments[].name)")
    ap.add_argument("--steps", nargs="+", default=["dataset", "merge", "train", "ga", "analyze"],
                    choices=["dataset", "merge", "train", "ga", "analyze"])
    ap.add_argument("--dry-run", action="store_true", help="Print commands only")
    ap.add_argument("--python", default=sys.executable, help="Python executable (default: current)")
    args = ap.parse_args()

    cfg_path = Path(args.config)
    cfg = load_config(cfg_path)

    root = Path(cfg.get("root", "."))
    exp = get_experiment(cfg, args.name)

    # allow experiment-local override
    if exp.get("root"):
        root = Path(exp["root"])

    steps = args.steps
    python_exe = args.python
    dry_run = args.dry_run

    for s in steps:
        if s == "dataset":
            step_dataset(exp, root, python_exe, dry_run)
        elif s == "merge":
            step_merge(exp, root, python_exe, dry_run)
        elif s == "train":
            step_train(exp, root, python_exe, dry_run)
        elif s == "ga":
            step_ga(exp, root, python_exe, dry_run)
        elif s == "analyze":
            step_analyze(exp, root, python_exe, dry_run)

    print("[DONE]", args.name, "steps:", steps)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# run_pipeline.ps1
# Thin wrapper: call run_experiments.py without editing any script.

param(
  [Parameter(Mandatory=$false)][string]$Config = "experiments.json",
  [Parameter(Mandatory=$true)][string]$Name,
  [Parameter(Mandatory=$false)][string[]]$Steps = @("dataset","merge","train","ga","analyze"),
  [switch]$DryRun
)

$ErrorActionPreference = "Stop"

Write-Host "=== Pipeline: $Name ==="
Write-Host "Config: $Config"
Write-Host "Steps : $($Steps -join ', ')"
if ($DryRun) { Write-Host "Mode  : DRY-RUN (no commands executed)" }

$cmd = @("python", "run_experiments.py", "--config", $Config, "--name", $Name, "--steps") + $Steps
if ($DryRun) { $cmd += "--dry-run" }

Write-Host ">>> " ($cmd -join " ")
& $cmd[0] $cmd[1..($cmd.Length-1)]
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "=== Done ==="
